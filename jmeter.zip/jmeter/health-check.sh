#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${BASE_DIR}/config/config.env"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "Missing ${CONFIG_FILE}. Run: bash setup.sh"
  exit 1
fi

# shellcheck disable=SC1090
source "${CONFIG_FILE}"

APP_NAME="${PM2_APP_NAME:-jmeter}"
APP_PORT="${APP_PORT:-3000}"

echo "Health Check"
echo "------------"

echo "Java:"
if command -v java >/dev/null 2>&1; then
  java -version 2>&1 | head -1
else
  echo "Not installed"
fi

echo ""
echo "Node:"
if command -v node >/dev/null 2>&1; then
  node -v
else
  echo "Not installed"
fi

echo ""
echo "PM2 app: ${APP_NAME}"
pm2 status "${APP_NAME}" || true

echo ""
echo "Port ${APP_PORT}:"
if command -v lsof >/dev/null 2>&1 && lsof -Pi :"${APP_PORT}" -sTCP:LISTEN -t >/dev/null 2>&1; then
  echo "Listening"
else
  echo "Not listening"
fi
