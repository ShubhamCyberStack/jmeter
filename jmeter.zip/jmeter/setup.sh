#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${BASE_DIR}/app"
CONFIG_DIR="${BASE_DIR}/config"
CONFIG_FILE="${CONFIG_DIR}/config.env"
CONFIG_EXAMPLE="${CONFIG_DIR}/config.env.example"
TARGET_USER="${SUDO_USER:-$USER}"
TARGET_HOME="$(eval echo "~${TARGET_USER}")"

mkdir -p "${CONFIG_DIR}" "${BASE_DIR}/core/jmeter" "${BASE_DIR}/logs" "${BASE_DIR}/data/tests" "${BASE_DIR}/data/reports"

if [[ -f "${CONFIG_FILE}" ]]; then
  # shellcheck disable=SC1090
  source "${CONFIG_FILE}"
else
  if [[ ! -f "${CONFIG_EXAMPLE}" ]]; then
    echo "Missing ${CONFIG_EXAMPLE}"
    exit 1
  fi

  sed "s|__BASE_DIR__|${BASE_DIR}|g" "${CONFIG_EXAMPLE}" > "${CONFIG_FILE}"
  # shellcheck disable=SC1090
  source "${CONFIG_FILE}"
fi

if [[ -z "${SESSION_SECRET:-}" || "${SESSION_SECRET}" == "change-this-to-a-long-random-secret" ]]; then
  if command -v openssl >/dev/null 2>&1; then
    SESSION_SECRET="$(openssl rand -base64 48 | tr -d '\n' | cut -c1-64)"
  else
    SESSION_SECRET="$(tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 64)"
  fi
fi

APP_PORT="${APP_PORT:-3000}"
PM2_APP_NAME="${PM2_APP_NAME:-jmeter}"
JMETER_VERSION="${JMETER_VERSION:-5.6.3}"
JMETER_DIR="${JMETER_DIR:-${BASE_DIR}/core/jmeter}"
JMETER_PATH="${JMETER_PATH:-${JMETER_DIR}/bin}"
TEST_FILE_NAME="${TEST_FILE_NAME:-testplan.jmx}"
RESULTS_FILE_NAME="${RESULTS_FILE_NAME:-results.jtl}"
REPORT_PREFIX="${REPORT_PREFIX:-report_}"
RUN_TIMEOUT_SECONDS="${RUN_TIMEOUT_SECONDS:-3600}"
NODE_ENV="${NODE_ENV:-production}"

if ! command -v apt-get >/dev/null 2>&1; then
  echo "setup.sh supports Debian/Ubuntu style apt-get environments."
  echo "Install dependencies manually and run bash start.sh"
  exit 1
fi

echo "[1/8] Installing system dependencies"
sudo apt-get update -qq
sudo apt-get install -y openjdk-21-jre wget tar nodejs npm curl ca-certificates >/dev/null 2>&1

echo "[2/8] Installing PM2"
sudo npm install -g pm2 >/dev/null 2>&1

echo "[3/8] Installing Apache JMeter ${JMETER_VERSION}"
mkdir -p "${JMETER_DIR}"
if [[ ! -x "${JMETER_PATH}/jmeter" ]]; then
  TMP_TGZ="${JMETER_DIR}/apache-jmeter-${JMETER_VERSION}.tgz"
  TMP_DIR="${JMETER_DIR}/apache-jmeter-${JMETER_VERSION}"
  wget -q -O "${TMP_TGZ}" "https://downloads.apache.org/jmeter/binaries/apache-jmeter-${JMETER_VERSION}.tgz"
  tar -xzf "${TMP_TGZ}" -C "${JMETER_DIR}"
  rm -f "${TMP_TGZ}"
  shopt -s dotglob
  mv "${TMP_DIR}"/* "${JMETER_DIR}/"
  shopt -u dotglob
  rmdir "${TMP_DIR}" 2>/dev/null || true
fi

echo "[4/8] Installing Node dependencies"
cd "${APP_DIR}"
npm install >/dev/null 2>&1

echo "[5/8] Writing runtime env"
cat > "${APP_DIR}/.env" <<EOF
PORT=${APP_PORT}
REPORT_SERVER_PORT=${APP_PORT}
SESSION_SECRET=${SESSION_SECRET}
JMETER_PATH=${JMETER_PATH}
TEST_FILE_NAME=${TEST_FILE_NAME}
RESULTS_FILE_NAME=${RESULTS_FILE_NAME}
REPORT_PREFIX=${REPORT_PREFIX}
RUN_TIMEOUT_SECONDS=${RUN_TIMEOUT_SECONDS}
NODE_ENV=${NODE_ENV}
EOF

echo "[6/8] Refreshing config/config.env"
cat > "${CONFIG_FILE}" <<EOF
BASE_DIR="${BASE_DIR}"
APP_DIR="${APP_DIR}"
JMETER_DIR="${JMETER_DIR}"
DATA_DIR="${BASE_DIR}/data"
TESTS_DIR="${BASE_DIR}/data/tests"
REPORTS_DIR="${BASE_DIR}/data/reports"
LOGS_DIR="${BASE_DIR}/logs"
APP_PORT=${APP_PORT}
PM2_APP_NAME="${PM2_APP_NAME}"
NODE_ENV=${NODE_ENV}
SESSION_SECRET="${SESSION_SECRET}"
JMETER_VERSION="${JMETER_VERSION}"
JMETER_PATH="${JMETER_PATH}"
TEST_FILE_NAME="${TEST_FILE_NAME}"
RESULTS_FILE_NAME="${RESULTS_FILE_NAME}"
REPORT_PREFIX="${REPORT_PREFIX}"
RUN_TIMEOUT_SECONDS=${RUN_TIMEOUT_SECONDS}
EOF

echo "[7/8] Setting execute permissions"
chmod +x "${BASE_DIR}/setup.sh" "${BASE_DIR}/start.sh" "${BASE_DIR}/stop.sh" "${BASE_DIR}/restart.sh" "${BASE_DIR}/health-check.sh" "${BASE_DIR}/scripts/pm2-service.sh"

echo "[8/8] Starting service"
cd "${BASE_DIR}"
bash "${BASE_DIR}/start.sh"
pm2 startup systemd -u "${TARGET_USER}" --hp "${TARGET_HOME}" >/dev/null 2>&1 || true

echo ""
echo "Setup complete"
echo "URL: http://localhost:${APP_PORT}"
echo "Admin username: admin"
echo "Admin password: admin@2026"
echo "JMeter path: ${JMETER_PATH}"
