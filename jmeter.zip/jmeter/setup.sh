#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_USER="${SUDO_USER:-$USER}"
TARGET_HOME="$(eval echo "~${TARGET_USER}")"

# Defaults
JMETER_VERSION="5.6.3"
JMETER_BASE_DIR="${TARGET_HOME}/tools"
JMETER_SYMLINK_NAME="jmeter"

APP_NAME="jmeter"
APP_PORT="3000"
REPORT_SERVER_PORT="3000"
SESSION_SECRET=""

TEST_FILE_NAME="testplan.jmx"
RESULTS_FILE_NAME="results.jtl"
REPORT_PREFIX="report_"

if [[ -f "${APP_DIR}/setup.conf" ]]; then
  # shellcheck disable=SC1091
  source "${APP_DIR}/setup.conf"
fi

if [[ -z "${SESSION_SECRET}" || "${SESSION_SECRET}" == "change-this-to-a-long-random-secret" ]]; then
  if command -v openssl >/dev/null 2>&1; then
    SESSION_SECRET="$(openssl rand -base64 48 | tr -d '\n' | cut -c1-64)"
  else
    set +o pipefail
    SESSION_SECRET="$(tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 64)"
    set -o pipefail
  fi
fi

# Hard lock ports to 3000 as required.
APP_PORT="3000"
REPORT_SERVER_PORT="3000"

JMETER_INSTALL_DIR="${JMETER_BASE_DIR}/${JMETER_SYMLINK_NAME}"
JMETER_BIN_DIR="${JMETER_INSTALL_DIR}/bin"

APP_DIR_REAL="$(readlink -f "${APP_DIR}")"
JMETER_INSTALL_REAL="$(readlink -m "${JMETER_INSTALL_DIR}")"
if [[ "${APP_DIR_REAL}" == "${JMETER_INSTALL_REAL}" || "${APP_DIR_REAL}" == "${JMETER_INSTALL_REAL}"/* || "${JMETER_INSTALL_REAL}" == "${APP_DIR_REAL}"/* ]]; then
  echo "ERROR: JMeter install path collides with app directory."
  echo "APP_DIR=${APP_DIR_REAL}"
  echo "JMETER_INSTALL_DIR=${JMETER_INSTALL_REAL}"
  echo "Set JMETER_BASE_DIR in setup.conf to a different path (example: /home/${TARGET_USER}/tools)."
  exit 1
fi

run_as_target() {
  sudo -u "${TARGET_USER}" -H bash -lc "$1"
}

echo "[1/8] Updating apt index"
sudo apt update

echo "[2/8] Installing system dependencies"
sudo apt install -y openjdk-21-jre wget tar nodejs npm curl ca-certificates

echo "[3/8] Installing PM2 globally"
sudo npm install -g pm2

echo "[4/8] Installing Apache JMeter ${JMETER_VERSION} if needed"
if [[ ! -x "${JMETER_BIN_DIR}/jmeter" ]]; then
  run_as_target "mkdir -p '${JMETER_BASE_DIR}'"
  TMP_TGZ="${JMETER_BASE_DIR}/apache-jmeter-${JMETER_VERSION}.tgz"
  TMP_DIR="${JMETER_BASE_DIR}/apache-jmeter-${JMETER_VERSION}"
  run_as_target "cd '${JMETER_BASE_DIR}' && wget -O '${TMP_TGZ}' 'https://downloads.apache.org/jmeter/binaries/apache-jmeter-${JMETER_VERSION}.tgz'"
  run_as_target "cd '${JMETER_BASE_DIR}' && tar -xzf '${TMP_TGZ}'"
  run_as_target "cd '${JMETER_BASE_DIR}' && rm -f '${TMP_TGZ}'"
  run_as_target "cd '${JMETER_BASE_DIR}' && rm -rf '${JMETER_SYMLINK_NAME}'"
  run_as_target "cd '${JMETER_BASE_DIR}' && mv '${TMP_DIR}' '${JMETER_SYMLINK_NAME}'"
fi

echo "[5/8] Ensuring app dependencies"
run_as_target "cd '${APP_DIR}' && npm install"

echo "[6/8] Preparing .env"
if [[ ! -f "${APP_DIR}/.env" ]]; then
  if [[ -f "${APP_DIR}/.env.example" ]]; then
    run_as_target "cp '${APP_DIR}/.env.example' '${APP_DIR}/.env'"
  else
    run_as_target "touch '${APP_DIR}/.env'"
  fi
fi

run_as_target "cat > '${APP_DIR}/.env' <<EOF
PORT=${APP_PORT}
REPORT_SERVER_PORT=${REPORT_SERVER_PORT}
SESSION_SECRET=${SESSION_SECRET}
JMETER_PATH=${JMETER_BIN_DIR}
TEST_FILE_NAME=${TEST_FILE_NAME}
RESULTS_FILE_NAME=${RESULTS_FILE_NAME}
REPORT_PREFIX=${REPORT_PREFIX}
EOF"

echo "[6.5/8] Ensuring setup.sh executable"
run_as_target "chmod +x '${APP_DIR}/setup.sh'"
run_as_target "chmod +x '${APP_DIR}/scripts/pm2-service.sh'"

echo "[7/8] Starting app with PM2"
run_as_target "cd '${APP_DIR}' && pm2 delete '${APP_NAME}' >/dev/null 2>&1 || true"
run_as_target "cd '${APP_DIR}' && pm2 start ecosystem.config.cjs --only '${APP_NAME}'"
run_as_target "pm2 save"

# Configure startup for the target user
sudo env PATH="$PATH" pm2 startup systemd -u "${TARGET_USER}" --hp "${TARGET_HOME}" >/tmp/pm2_startup_cmd.txt 2>/dev/null || true
if grep -q "sudo" /tmp/pm2_startup_cmd.txt; then
  STARTUP_CMD="$(grep -Eo 'sudo .*$' /tmp/pm2_startup_cmd.txt | head -n1 || true)"
  if [[ -n "${STARTUP_CMD}" ]]; then
    eval "${STARTUP_CMD}"
  fi
fi

echo "[8/8] Verifying service status"
run_as_target "pm2 status '${APP_NAME}'"

echo
echo "Setup complete"
echo "UI URL: http://<server-ip>:${APP_PORT}"
echo "Admin username: admin"
echo "Admin password: admin@2026"
echo "JMeter bin path: ${JMETER_BIN_DIR}"
echo "Session secret: auto-generated"
