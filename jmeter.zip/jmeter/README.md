# JMeter Control Panel (Developer UI)

A web dashboard for developers to run JMeter tests without manually writing JMX XML.

## One-command server setup

After copying this folder to Ubuntu server:

1. Run setup directly (no config file needed):

```bash
bash setup.sh
```

This is enough. The script uses defaults and does everything automatically.

Defaults used automatically:

- app port: `3000`
- PM2 app name: `jmeter`
- JMeter version: `5.6.3`
- JMeter install path: `/home/<user>/jmeter/jmeter/bin`
- secure `SESSION_SECRET`: auto-generated

Optional advanced override (only if you want custom path/version):

```bash
cp setup.conf.example setup.conf
nano setup.conf
bash setup.sh
```

The script will automatically:

- update apt index
- install Java, Node.js, npm, curl, wget
- install Apache JMeter
- install PM2
- install app dependencies
- generate `.env` with configured paths
- force app ports to 3000
- start app with PM2 and enable startup

## PM2 automation files

- `ecosystem.config.cjs` : PM2 app definition for continuous running
- `scripts/pm2-service.sh` : helper commands for start/restart/status/logs

Common commands:

```bash
./scripts/pm2-service.sh start
./scripts/pm2-service.sh status
./scripts/pm2-service.sh logs
./scripts/pm2-service.sh restart
```

## What this build supports

- Login page as first screen
- Fixed single admin account:
	- Username: admin
	- Password: admin@2026
	- Email: shubham.s@mail.arthimpact.in
- Admin can add/delete normal users
- Normal users login with username and password
- Per-user isolated test plan storage
- Test plan builder for:
	- Website testing
	- Backend API testing (auth + encryption modes)
	- Payment gateway flow testing
	- Manual script mode (write/edit full JMX)
- Save plan first, then run
- Global run lock (only one run at a time)
- Queue-based run orchestration (heavy runs are queued and processed sequentially)
- Live logs and running status on dashboard
- Reports list for all users
- Report deletion only for admin
- Security hardening headers + API/login rate limiting
- Operational health endpoints

## Folder structure

- server.js
- public/login.html
- public/app.html
- data/users.json (auto-created)
- data/user-plans/*.json (auto-created per user)

## Environment (.env)

Use `.env.example` as reference.

```env
PORT=3000
REPORT_SERVER_PORT=3000
SESSION_SECRET=change-this-to-a-long-random-secret
JMETER_PATH=/home/arth1/jmeter/jmeter/bin
TEST_FILE_NAME=testplan.jmx
RESULTS_FILE_NAME=results.jtl
REPORT_PREFIX=report_
```

## Ubuntu setup

Recommended: use setup.sh flow above.

Open in browser after setup:

```text
http://<server-ip>:3000
```

## PM2 run (recommended)

`setup.sh` already configures PM2. Manual commands (optional):

```bash
sudo npm install -g pm2
cd ~/jmeter
pm2 start ecosystem.config.cjs --only jmeter
pm2 save
pm2 startup
```

Useful commands:

```bash
pm2 status
pm2 logs jmeter
pm2 restart jmeter
```

## How test run works

1. User fills test plan form and saves.
2. Saved plan is isolated to that user only.
3. On run:
	 - App generates JMX from that user plan.
	 - Writes generated JMX to real `testplan.jmx` at JMeter path.
	 - Clears previous result/report target.
	 - Executes JMeter CLI in non-GUI mode.
4. Latest report becomes available through dashboard.

## Notes

- If user-2 clicks run while user-1 test is active, run is blocked and UI shows running banner + elapsed seconds.
- For API encryption mode:
	- `none`
	- `base64`
	- `aes-cbc` using JSR223 Groovy preprocessors/postprocessors.
- Keep this app behind firewall or reverse proxy in production.

## Monitoring endpoints

- `GET /healthz` : liveness and queue state
- `GET /readyz` : readiness checks for JMeter path/binary/data files
- `GET /metrics` : runtime counters (auth, queue, runs, reports)

## Queue behavior

- `/api/run` now enqueues jobs for processing.
- Only one JMeter process runs at a time.
- Additional requests are queued (up to max queue size) and run automatically.
- Dashboard shows running user, elapsed time, and waiting queue count.

## Final Ubuntu Run Steps (After Copying Folder)

After you upload this full project folder to Ubuntu server, run these steps exactly:

1. Go to project folder:

```bash
cd /path/to/jmeter
```

2. Run full automatic setup:

```bash
bash setup.sh
```

3. Verify PM2 app is running:

```bash
./scripts/pm2-service.sh status
```

4. Open application in browser:

```text
http://<server-ip>:3000
```

5. Default admin login:

- Username: `admin`
- Password: `admin@2026`

6. If app is not reachable, check logs:

```bash
./scripts/pm2-service.sh logs
```

7. Health checks:

```bash
curl -s http://localhost:3000/healthz
curl -s http://localhost:3000/readyz
curl -s http://localhost:3000/metrics
```

This is the full post-copy flow to run the app successfully.
