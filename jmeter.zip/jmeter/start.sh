#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${BASE_DIR}/app"
CONFIG_FILE="${BASE_DIR}/config/config.env"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "Missing ${CONFIG_FILE}. Run: bash setup.sh"
  exit 1
fi

# shellcheck disable=SC1090
source "${CONFIG_FILE}"

APP_NAME="${PM2_APP_NAME:-jmeter}"
LOGS_DIR="${LOGS_DIR:-${BASE_DIR}/logs}"
mkdir -p "${LOGS_DIR}"

cd "${APP_DIR}"
pm2 stop "${APP_NAME}" >/dev/null 2>&1 || true
pm2 delete "${APP_NAME}" >/dev/null 2>&1 || true
pm2 start ecosystem.config.cjs --only "${APP_NAME}" --update-env
pm2 save >/dev/null 2>&1 || true

echo "Services started"
echo "URL: http://localhost:${APP_PORT:-3000}"
