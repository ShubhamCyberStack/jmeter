#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${BASE_DIR}/app"
CONFIG_FILE="${BASE_DIR}/config/config.env"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "Missing ${CONFIG_FILE}. Run: bash setup.sh"
  exit 1
fi

# shellcheck disable=SC1090
source "${CONFIG_FILE}"

APP_NAME="${PM2_APP_NAME:-jmeter}"
LOGS_DIR="${LOGS_DIR:-${BASE_DIR}/logs}"
mkdir -p "${LOGS_DIR}"

if [[ ! -f "${APP_DIR}/server.js" ]]; then
  echo "Missing ${APP_DIR}/server.js"
  exit 1
fi

cd "${APP_DIR}"
pm2 stop "${APP_NAME}" >/dev/null 2>&1 || true
pm2 delete "${APP_NAME}" >/dev/null 2>&1 || true
# Backward-compat cleanup for older process names.
pm2 stop "jmeter-ui" >/dev/null 2>&1 || true
pm2 delete "jmeter-ui" >/dev/null 2>&1 || true
pm2 start "${APP_DIR}/server.js" --name "${APP_NAME}" --cwd "${APP_DIR}" --update-env
pm2 save >/dev/null 2>&1 || true

echo "Services started"
echo "URL: http://localhost:${APP_PORT:-3000}"
