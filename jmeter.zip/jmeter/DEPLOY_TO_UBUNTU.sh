#!/bin/bash
# JMETER CONTROL PANEL - UBUNTU SERVER DEPLOYMENT
# Final Deployment Script for AWS EC2 Ubuntu Server
# Target: 13.232.253.210:3000

set -e

echo "=========================================="
echo "JMeter Control Panel - Ubuntu Deployment"
echo "=========================================="
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Step 1: Extract and prepare
echo -e "${YELLOW}[1/6]${NC} Preparing project files..."
cd /home/ubuntu
if [ -d "jmeter" ]; then
    echo "    Removing old jmeter directory..."
    rm -rf jmeter
fi

# Unzip the uploaded file (user should have uploaded jmeter.zip)
if [ -f "jmeter.zip" ]; then
    unzip -q jmeter.zip
    rm jmeter.zip
    echo -e "${GREEN}✓${NC} Project extracted"
else
    echo -e "${RED}✗${NC} jmeter.zip not found. Please upload it first."
    exit 1
fi

cd jmeter

# Step 2: Fix line endings if needed
echo -e "${YELLOW}[2/6]${NC} Normalizing line endings..."
find . -name "*.sh" -type f -exec dos2unix {} \; 2>/dev/null || true
find . -name "setup.conf" -type f -exec dos2unix {} \; 2>/dev/null || true
chmod +x setup.sh start.sh stop.sh restart.sh health-check.sh 2>/dev/null || true
echo -e "${GREEN}✓${NC} Line endings normalized"

# Step 3: Run setup
echo -e "${YELLOW}[3/6]${NC} Running setup.sh (installs Java, JMeter, PM2)..."
bash setup.sh
echo -e "${GREEN}✓${NC} Setup completed"

# Step 4: Generate config if not exists
echo -e "${YELLOW}[4/6]${NC} Configuring application..."
if [ ! -f "config/config.env" ]; then
    echo "    Generating config.env..."
    # Replace __BASE_DIR__ with actual path
    sed 's|__BASE_DIR__|/home/ubuntu/jmeter|g' config/config.env.example > config/config.env
    sed -i 's/\r$//' config/config.env
fi

if [ ! -f "app/.env" ]; then
    echo "    Generating app/.env..."
    cp app/.env.example app/.env 2>/dev/null || cat > app/.env << 'APPENV'
PORT=3000
REPORT_SERVER_PORT=3000
SESSION_SECRET="change-this-to-a-long-random-secret-$(date +%s)"
JMETER_PATH=/home/ubuntu/jmeter/core/jmeter/bin
TEST_FILE_NAME=testplan.jmx
RESULTS_FILE_NAME=results.jtl
REPORT_PREFIX=report_
RUN_TIMEOUT_SECONDS=3600
NODE_ENV=production
JMETER_HEAP_MIN=128m
JMETER_HEAP_MAX=256m
JMETER_METASPACE_MAX=96m
JMETER_JVM_ARGS=-Djava.awt.headless=true -XX:+UseSerialGC
APPENV
fi
echo -e "${GREEN}✓${NC} Configuration created"

# Step 5: Start the application
echo -e "${YELLOW}[5/6]${NC} Starting application with PM2..."
bash start.sh
sleep 3
echo -e "${GREEN}✓${NC} Application started"

# Step 6: Verify health
echo -e "${YELLOW}[6/6]${NC} Verifying deployment..."
bash health-check.sh

echo ""
echo -e "${GREEN}=========================================="
echo "✓ DEPLOYMENT COMPLETE"
echo "==========================================${NC}"
echo ""
echo "Access your JMeter Control Panel at:"
echo -e "${GREEN}  http://13.232.253.210:3000${NC}"
echo ""
echo "Default credentials:"
echo "  Username: admin"
echo "  Password: admin@2026"
echo ""
echo "Useful commands:"
echo "  Start:    cd /home/ubuntu/jmeter && bash start.sh"
echo "  Stop:     cd /home/ubuntu/jmeter && bash stop.sh"
echo "  Restart:  cd /home/ubuntu/jmeter && bash restart.sh"
echo "  Health:   cd /home/ubuntu/jmeter && bash health-check.sh"
echo "  Logs:     pm2 logs jmeter --lines 100"
echo ""
