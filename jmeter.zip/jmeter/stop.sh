#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${BASE_DIR}/config/config.env"

APP_NAME="jmeter"
if [[ -f "${CONFIG_FILE}" ]]; then
  # shellcheck disable=SC1090
  source "${CONFIG_FILE}"
  APP_NAME="${PM2_APP_NAME:-jmeter}"
fi

pm2 stop "${APP_NAME}" >/dev/null 2>&1 || true
pm2 delete "${APP_NAME}" >/dev/null 2>&1 || true

echo "Services stopped"
