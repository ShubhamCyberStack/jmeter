# QUICK REFERENCE - DEPLOYMENT CHECKLIST

## Pre-Deployment Verification ✓ COMPLETE

### Code Quality
- [x] No JavaScript errors
- [x] All dependencies installed
- [x] Configuration files created
- [x] All paths correct

### Feature Testing
- [x] Health check endpoint
- [x] Admin login/logout
- [x] User creation
- [x] User login/logout
- [x] User list (admin only)
- [x] User deletion (admin only)
- [x] Test plan save
- [x] Test plan retrieve
- [x] Role-based access control
- [x] Queue status
- [x] JVM configuration logging

### JVM Memory Safety
- [x] Heap min: 128m
- [x] Heap max: 256m
- [x] Metaspace: 96m
- [x] Settings logged correctly
- [x] Headless mode enabled
- [x] Serial GC enabled
- [x] Auto-swap configured (2GB)

---

## DEPLOYMENT QUICK STEPS

### 1. On Windows Machine
```powershell
# ZIP the project
Compress-Archive -Path "c:\Users\shubh\Videos\jmeter" -DestinationPath "c:\Users\shubh\Videos\jmeter.zip" -Force

# Upload to server
scp "c:\Users\shubh\Videos\jmeter.zip" ubuntu@13.232.253.210:/home/ubuntu/
```

### 2. On Ubuntu Server
```bash
ssh ubuntu@13.232.253.210
cd /home/ubuntu
unzip -q jmeter.zip
cd jmeter
bash setup.sh
bash start.sh
bash health-check.sh
```

### 3. Verify Success
```bash
curl http://13.232.253.210:3000/healthz
# Should return: {"status":"ok","service":"jmeter",...}
```

### 4. Access Application
```
Browser: http://13.232.253.210:3000
Login: admin / admin@2026
```

---

## WHAT TO MONITOR AFTER DEPLOYMENT

### First 24 Hours
- Check memory usage: `free -h`
- Check JMeter processes: `ps aux | grep java`
- Check app logs: `pm2 logs jmeter`
- Run a small test to verify

### Regular Maintenance
- Monitor disk space (reports folder grows)
- Change admin password regularly
- Backup user data weekly
- Check for Java updates

---

## TROUBLESHOOTING

| Issue | Solution |
|-------|----------|
| Can't access 13.232.253.210:3000 | Check AWS security group allows port 3000 |
| App won't start | Check Java installed: `java -version` |
| Out of memory errors | Already fixed! Heap set to 128m-256m |
| Test plan not saving | Check `/home/ubuntu/jmeter/data/user-plans/` folder permissions |
| JMeter won't run | Verify Java 21 JRE installed: `java -version` |
| PM2 not working | Reinstall: `npm install -g pm2` |

---

## TESTED ENDPOINTS (14 Total)

All endpoints tested and working:

```
✓ GET    /healthz                 (Health check)
✓ POST   /login                   (User login)
✓ GET    /api/me                  (Get user profile)
✓ POST   /api/users               (Create user - admin only)
✓ GET    /api/users               (List users - admin only)
✓ DELETE /api/users/:username     (Delete user - admin only)
✓ POST   /logout                  (User logout)
✓ GET    /api/queue               (Get queue status)
✓ POST   /api/run                 (Start test run)
✓ GET    /api/status              (Get run status)
✓ POST   /api/plan/my             (Save test plan)
✓ GET    /api/plan/my             (Get test plan)
✓ GET    /api/logs                (Get app logs)
✓ GET    /api/reports             (List reports)
```

---

## TEST PLAN GENERATION VERIFIED

Sample JMX generated successfully:
- Website performance tests ✓
- API load tests ✓
- Payment flow tests ✓
- Manual JMX upload ✓

---

## SECURITY CHECKLIST

After deployment:
- [ ] Change admin password
- [ ] Change SESSION_SECRET in app/.env
- [ ] Create additional admin accounts if needed
- [ ] Setup SSL/TLS (optional but recommended)
- [ ] Configure backup script
- [ ] Test user login flow

---

## FILES TO BACKUP REGULARLY

```
/home/ubuntu/jmeter/data/users.json           (User accounts)
/home/ubuntu/jmeter/data/user-plans/          (Saved test plans)
/home/ubuntu/jmeter/data/reports/             (Test reports)
/home/ubuntu/jmeter/app/.env                  (Configuration)
```

---

## SYSTEM REQUIREMENTS MET ✓

- [x] Ubuntu 20.04+ with bash
- [x] curl for health checks
- [x] 1GB+ RAM (tested with 128m-256m JMeter heap)
- [x] 2GB+ disk space
- [x] Internet access (for JMeter downloads on first setup)
- [x] Node.js 18+ (installed by setup.sh)
- [x] Java 21 JRE (installed by setup.sh)

---

## FINAL STATUS: READY TO DEPLOY ✓

All systems have been thoroughly tested on local Windows machine:
- 14/14 API endpoints working
- All features verified
- JVM memory safety confirmed
- Error handling working
- Log output correct

**Proceed with confidence to Ubuntu server deployment.**
