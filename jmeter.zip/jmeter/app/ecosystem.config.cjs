module.exports = {
  apps: [
    {
      name: 'jmeter',
      script: 'server.js',
      cwd: __dirname,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      watch: false,
      max_memory_restart: '1024M',
      env: {
        NODE_ENV: 'production',
        PORT: '3000',
        REPORT_SERVER_PORT: '3000'
      }
    }
  ]
};
