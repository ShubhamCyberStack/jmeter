const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', 'config', 'config.env') });
require('dotenv').config({ path: path.join(__dirname, '.env') });

const express = require('express');
const session = require('express-session');
const { spawn, execSync } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');

const app = express();

const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET = process.env.SESSION_SECRET || 'change-this-secret';
const REPORT_SERVER_PORT = Number(process.env.REPORT_SERVER_PORT || PORT);

const JMETER_PATH = (process.env.JMETER_PATH || '').trim();
const TEST_FILE_NAME = process.env.TEST_FILE_NAME || 'testplan.jmx';
const RESULTS_FILE_NAME = process.env.RESULTS_FILE_NAME || 'results.jtl';
const REPORT_PREFIX = process.env.REPORT_PREFIX || 'report_';
const RUN_TIMEOUT_SECONDS = Number(process.env.RUN_TIMEOUT_SECONDS || 3600);

const TEST_FILE = path.join(JMETER_PATH, TEST_FILE_NAME);
const RESULTS_FILE = path.join(JMETER_PATH, RESULTS_FILE_NAME);
const JMETER_BIN = path.join(JMETER_PATH, 'jmeter');
const JMETER_PATH_DISPLAY = JMETER_PATH || '(not configured)';

const DATA_DIR = path.join(__dirname, '..', 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const USER_PLAN_DIR = path.join(DATA_DIR, 'user-plans');

const ADMIN_USER = {
  username: 'admin',
  password: 'admin@2026',
  email: 'shubham.s@mail.arthimpact.in'
};

const PLAN_TYPES = [
  {
    id: 'website',
    label: 'Website Performance Test',
    description: 'Test website pages, redirects, and static content delivery.'
  },
  {
    id: 'api',
    label: 'Backend API Test',
    description: 'Test REST APIs with auth, headers, payloads, and encryption modes.'
  },
  {
    id: 'payment',
    label: 'Payment Gateway Flow',
    description: 'Test initiate-payment and transaction-status flow for payment systems.'
  },
  {
    id: 'manual',
    label: 'Manual Script (JMX Editor)',
    description: 'Write and run your own JMeter JMX script directly.'
  }
];

const MANUAL_SCRIPT_SAMPLE = `<?xml version="1.0" encoding="UTF-8"?>
<jmeterTestPlan version="1.2" properties="5.0" jmeter="5.6.3">
  <hashTree>
    <TestPlan guiclass="TestPlanGui" testclass="TestPlan" testname="Manual Script Sample" enabled="true">
      <stringProp name="TestPlan.comments">Editable manual script from dashboard editor</stringProp>
      <boolProp name="TestPlan.functional_mode">false</boolProp>
      <boolProp name="TestPlan.tearDown_on_shutdown">true</boolProp>
      <boolProp name="TestPlan.serialize_threadgroups">false</boolProp>
      <elementProp name="TestPlan.user_defined_variables" elementType="Arguments" guiclass="ArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true">
        <collectionProp name="Arguments.arguments"/>
      </elementProp>
      <stringProp name="TestPlan.user_define_classpath"></stringProp>
    </TestPlan>
    <hashTree>
      <ThreadGroup guiclass="ThreadGroupGui" testclass="ThreadGroup" testname="Thread Group" enabled="true">
        <stringProp name="ThreadGroup.on_sample_error">continue</stringProp>
        <elementProp name="ThreadGroup.main_controller" elementType="LoopController" guiclass="LoopControlPanel" testclass="LoopController" testname="Loop Controller" enabled="true">
          <boolProp name="LoopController.continue_forever">false</boolProp>
          <stringProp name="LoopController.loops">1</stringProp>
        </elementProp>
        <stringProp name="ThreadGroup.num_threads">5</stringProp>
        <stringProp name="ThreadGroup.ramp_time">10</stringProp>
        <boolProp name="ThreadGroup.scheduler">false</boolProp>
        <stringProp name="ThreadGroup.duration"></stringProp>
        <stringProp name="ThreadGroup.delay"></stringProp>
      </ThreadGroup>
      <hashTree>
        <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="HTTP Request" enabled="true">
          <elementProp name="HTTPsampler.Arguments" elementType="Arguments" guiclass="HTTPArgumentsPanel" testclass="Arguments" enabled="true">
            <collectionProp name="Arguments.arguments"/>
          </elementProp>
          <stringProp name="HTTPSampler.domain">example.com</stringProp>
          <stringProp name="HTTPSampler.port"></stringProp>
          <stringProp name="HTTPSampler.protocol">https</stringProp>
          <stringProp name="HTTPSampler.path">/</stringProp>
          <stringProp name="HTTPSampler.method">GET</stringProp>
          <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
          <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
          <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
          <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
          <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
        </HTTPSamplerProxy>
        <hashTree/>
      </hashTree>
    </hashTree>
  </hashTree>
</jmeterTestPlan>
`;

const runState = {
  running: false,
  currentJobId: null,
  currentJobStartedAt: null,
  startedAt: null,
  startedBy: null,
  reportFolder: null,
  latestReport: null,
  lastRun: {
    startedAt: null,
    finishedAt: null,
    startedBy: null,
    reportFolder: null,
    exitCode: null,
    status: 'idle'
  },
  logs: []
};

const serverStartedAt = Date.now();
const MAX_QUEUE_SIZE = 30;
const runQueue = [];
let nextRunJobId = 1;
let currentRunChild = null;
let currentRunTimer = null;

let preflightState = {
  timestamp: null,
  healthy: false,
  checks: [],
  suggestedFixes: []
};

const metrics = {
  authSuccess: 0,
  authFailures: 0,
  runEnqueued: 0,
  runStarted: 0,
  runCompleted: 0,
  runFailed: 0,
  reportsDeleted: 0
};

const rateLimitStore = new Map();

function ensureDirs() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(USER_PLAN_DIR, { recursive: true });
}

function applySecurityHeaders(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('X-XSS-Protection', '0');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  next();
}

function createRateLimiter({ windowMs, maxRequests, bucketName }) {
  return (req, res, next) => {
    const key = `${bucketName}:${req.ip || req.socket.remoteAddress || 'unknown'}`;
    const now = Date.now();
    const bucket = rateLimitStore.get(key) || { count: 0, resetAt: now + windowMs };

    if (now > bucket.resetAt) {
      bucket.count = 0;
      bucket.resetAt = now + windowMs;
    }

    bucket.count += 1;
    rateLimitStore.set(key, bucket);

    if (bucket.count > maxRequests) {
      const retrySeconds = Math.max(1, Math.ceil((bucket.resetAt - now) / 1000));
      res.setHeader('Retry-After', String(retrySeconds));
      return res.status(429).json({ success: false, message: 'Too many requests. Try again soon.' });
    }

    next();
  };
}

const apiLimiter = createRateLimiter({ windowMs: 60 * 1000, maxRequests: 240, bucketName: 'api' });
const loginLimiter = createRateLimiter({ windowMs: 15 * 60 * 1000, maxRequests: 50, bucketName: 'login' });
const runLimiter = createRateLimiter({ windowMs: 60 * 1000, maxRequests: 25, bucketName: 'run' });

function runSafeCommand(command, cwd) {
  try {
    const output = execSync(command, {
      cwd: cwd || process.cwd(),
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 5000,
      encoding: 'utf-8'
    });
    return { ok: true, output: String(output || '').trim() };
  } catch (err) {
    const stdout = err && err.stdout ? String(err.stdout) : '';
    const stderr = err && err.stderr ? String(err.stderr) : '';
    return { ok: false, output: `${stdout}\n${stderr}`.trim() || String(err.message || err) };
  }
}

function getDiskFreeMb(targetPath) {
  if (process.platform !== 'linux') {
    return null;
  }

  const safePath = targetPath || '/';
  const result = runSafeCommand(`df -Pm "${safePath}" | tail -1 | awk '{print $4}'`);
  if (!result.ok) {
    return null;
  }

  const value = Number(result.output);
  if (!Number.isFinite(value)) {
    return null;
  }

  return value;
}

function runPreflightChecks() {
  const checks = [];
  const fixes = [];

  const pushCheck = (name, ok, details, fixCommand) => {
    checks.push({ name, ok, details });
    if (!ok && fixCommand) {
      fixes.push(fixCommand);
    }
  };

  pushCheck('JMETER_PATH configured', Boolean(JMETER_PATH), JMETER_PATH || 'Not configured', 'Edit .env and set JMETER_PATH=/home/<user>/jmeter/jmeter/bin');
  pushCheck('JMETER_PATH exists', Boolean(JMETER_PATH) && fs.existsSync(JMETER_PATH), JMETER_PATH || 'Not configured', 'Run ./setup.sh to install/configure JMeter path');
  pushCheck('JMeter binary exists', Boolean(JMETER_PATH) && fs.existsSync(JMETER_BIN), JMETER_BIN || 'Not configured', 'Run ./setup.sh or verify jmeter exists at JMETER_PATH');

  let writable = false;
  if (JMETER_PATH && fs.existsSync(JMETER_PATH)) {
    try {
      fs.accessSync(JMETER_PATH, fs.constants.W_OK);
      writable = true;
    } catch (err) {
      writable = false;
    }
  }
  pushCheck('JMETER_PATH writable', writable, writable ? 'Writable' : 'Not writable', `sudo chown -R $USER:$USER "${JMETER_PATH || '/home/<user>/jmeter/jmeter/bin'}"`);

  const javaVersion = runSafeCommand('java -version 2>&1');
  pushCheck('Java available', javaVersion.ok, javaVersion.ok ? (javaVersion.output.split('\n')[0] || 'OK') : javaVersion.output, 'sudo apt install -y openjdk-21-jre');

  const jmeterVersion = JMETER_PATH && fs.existsSync(JMETER_BIN)
    ? runSafeCommand(`"${JMETER_BIN}" -v`, JMETER_PATH)
    : { ok: false, output: 'JMeter binary missing' };
  pushCheck('JMeter executable', jmeterVersion.ok, jmeterVersion.ok ? (jmeterVersion.output.split('\n')[0] || 'OK') : jmeterVersion.output, 'Run ./setup.sh to reinstall JMeter');

  const freeMb = getDiskFreeMb(JMETER_PATH || '/');
  if (freeMb == null) {
    pushCheck('Disk free space', true, 'Skipped (non-linux or unavailable)', '');
  } else {
    const enoughDisk = freeMb >= 1024;
    pushCheck('Disk free space', enoughDisk, `${freeMb} MB free`, 'Free disk space (at least 1GB recommended)');
  }

  preflightState = {
    timestamp: new Date().toISOString(),
    healthy: checks.every((c) => c.ok),
    checks,
    suggestedFixes: fixes
  };

  return preflightState;
}

function selfHealArtifacts() {
  if (!JMETER_PATH || !fs.existsSync(JMETER_PATH)) {
    return;
  }

  try {
    if (!fs.existsSync(TEST_FILE)) {
      fs.writeFileSync(TEST_FILE, MANUAL_SCRIPT_SAMPLE, 'utf-8');
      appendLog('Self-heal: created missing test plan file from sample template.');
    }
  } catch (err) {
    appendLog(`Self-heal warning: failed creating default test plan (${err.message}).`);
  }
}

function makePasswordHash(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}

function verifyPassword(password, salt, hash) {
  const candidate = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(candidate, 'hex'), Buffer.from(hash, 'hex'));
}

function readUsers() {
  if (!fs.existsSync(USERS_FILE)) {
    return [];
  }
  try {
    return JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8'));
  } catch (err) {
    return [];
  }
}

function writeUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
}

function ensureAdminUser() {
  let users = readUsers();
  const adminUsers = users.filter((u) => u.role === 'admin');

  if (adminUsers.length === 0) {
    const secure = makePasswordHash(ADMIN_USER.password);
    users.push({
      username: ADMIN_USER.username,
      email: ADMIN_USER.email,
      role: 'admin',
      passwordHash: secure.hash,
      salt: secure.salt,
      createdAt: new Date().toISOString()
    });
    writeUsers(users);
    return;
  }

  if (adminUsers.length > 1) {
    const firstAdmin = adminUsers[0];
    users = users.filter((u) => u.role !== 'admin' || u.username === firstAdmin.username);
  }

  const adminSecure = makePasswordHash(ADMIN_USER.password);

  users = users.map((u) => {
    if (u.role === 'admin') {
      return {
        ...u,
        username: ADMIN_USER.username,
        email: ADMIN_USER.email,
        passwordHash: adminSecure.hash,
        salt: adminSecure.salt
      };
    }
    return u;
  });

  writeUsers(users);
}

function getSafeUser(user) {
  return {
    username: user.username,
    email: user.email,
    role: user.role,
    createdAt: user.createdAt
  };
}

function getPlanFile(username) {
  return path.join(USER_PLAN_DIR, `${username}.json`);
}

function defaultPlan() {
  return {
    type: 'website',
    name: 'My Website Smoke Test',
    load: {
      users: 5,
      rampUp: 10,
      loops: 1
    },
    settings: {
      targetUrl: 'https://example.com/',
      method: 'GET',
      headersJson: '{}',
      body: '',
      followRedirects: true,
      manualScript: MANUAL_SCRIPT_SAMPLE
    },
    savedAt: null
  };
}

function parseJsonObject(text, fieldName) {
  if (!text || !String(text).trim()) {
    return {};
  }
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch (err) {
    throw new Error(`${fieldName} must be valid JSON.`);
  }
  if (parsed === null || Array.isArray(parsed) || typeof parsed !== 'object') {
    throw new Error(`${fieldName} must be a JSON object.`);
  }
  return parsed;
}

function normalizePlan(input) {
  const plan = input || {};
  const type = String(plan.type || '').trim();
  const validTypes = PLAN_TYPES.map((t) => t.id);
  if (!validTypes.includes(type)) {
    throw new Error('Invalid test type selected.');
  }

  const load = plan.load || {};
  const users = Number(load.users);
  const rampUp = Number(load.rampUp);
  const loops = Number(load.loops);

  if (!Number.isInteger(users) || users < 1 || users > 200000) {
    throw new Error('users must be between 1 and 200000.');
  }
  if (!Number.isInteger(rampUp) || rampUp < 0 || rampUp > 86400) {
    throw new Error('rampUp must be between 0 and 86400.');
  }
  if (!Number.isInteger(loops) || loops < 1 || loops > 1000000) {
    throw new Error('loops must be between 1 and 1000000.');
  }

  const name = String(plan.name || '').trim() || `${type} plan`;
  const settings = plan.settings || {};

  if (type === 'website') {
    if (!settings.targetUrl) throw new Error('Website target URL is required.');
    new URL(String(settings.targetUrl));
  }

  if (type === 'api') {
    if (!settings.baseUrl) throw new Error('API base URL is required.');
    new URL(String(settings.baseUrl));
    if (!settings.endpointPath) throw new Error('API endpoint path is required.');
    parseJsonObject(settings.headersJson || '{}', 'API headers');
    if (settings.authType === 'apiKey' && (!settings.apiKeyName || !settings.apiKeyValue)) {
      throw new Error('API key name and value are required for API key auth.');
    }
    if (settings.authType === 'basic' && (!settings.authUsername || !settings.authPassword)) {
      throw new Error('Username and password are required for Basic auth.');
    }
    if (settings.encryptionMode === 'aes-cbc' && (!settings.aesKey || !settings.aesIv)) {
      throw new Error('AES key and IV are required for AES-CBC mode.');
    }
  }

  if (type === 'payment') {
    if (!settings.gatewayBaseUrl) throw new Error('Gateway base URL is required.');
    new URL(String(settings.gatewayBaseUrl));
    if (!settings.initiatePath || !settings.statusPath) {
      throw new Error('Initiate and status paths are required for payment tests.');
    }
  }

  if (type === 'manual') {
    const script = String(settings.manualScript || '').trim();
    if (!script) {
      throw new Error('Manual script is required.');
    }
    if (!script.includes('<jmeterTestPlan')) {
      throw new Error('Manual script must be a valid JMeter .jmx XML with <jmeterTestPlan>.');
    }
  }

  return {
    type,
    name,
    load: { users, rampUp, loops },
    settings,
    savedAt: new Date().toISOString()
  };
}

function readUserPlan(username) {
  const filePath = getPlanFile(username);
  if (!fs.existsSync(filePath)) return defaultPlan();
  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    return normalizePlan(parsed);
  } catch (err) {
    return defaultPlan();
  }
}

function saveUserPlan(username, plan) {
  const normalized = normalizePlan(plan);
  fs.writeFileSync(getPlanFile(username), JSON.stringify(normalized, null, 2), 'utf-8');
  return normalized;
}

function xmlEscape(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function splitUrl(urlText) {
  const urlObj = new URL(urlText);
  return {
    protocol: urlObj.protocol.replace(':', ''),
    domain: urlObj.hostname,
    path: `${urlObj.pathname || '/'}${urlObj.search || ''}`
  };
}

function buildHeaderManager(headers) {
  const entries = Object.entries(headers || {});
  if (entries.length === 0) {
    return '<hashTree/>';
  }

  const items = entries
    .map(([name, value]) => {
      return `<elementProp name="${xmlEscape(name)}" elementType="Header"><stringProp name="Header.name">${xmlEscape(name)}</stringProp><stringProp name="Header.value">${xmlEscape(value)}</stringProp></elementProp>`;
    })
    .join('');

  return `<HeaderManager guiclass="HeaderPanel" testclass="HeaderManager" testname="HTTP Header Manager" enabled="true"><collectionProp name="HeaderManager.headers">${items}</collectionProp></HeaderManager><hashTree/>`;
}

function buildBodyArguments(bodyExpression) {
  if (!bodyExpression) {
    return '<elementProp name="HTTPsampler.Arguments" elementType="Arguments"><collectionProp name="Arguments.arguments"/></elementProp><boolProp name="HTTPSampler.postBodyRaw">false</boolProp>';
  }

  return `<elementProp name="HTTPsampler.Arguments" elementType="Arguments"><collectionProp name="Arguments.arguments"><elementProp name="" elementType="HTTPArgument"><boolProp name="HTTPArgument.always_encode">false</boolProp><stringProp name="Argument.value">${xmlEscape(bodyExpression)}</stringProp><stringProp name="Argument.metadata">=</stringProp></elementProp></collectionProp></elementProp><boolProp name="HTTPSampler.postBodyRaw">true</boolProp>`;
}

function buildHttpSampler({ name, method, url, bodyExpression, followRedirects = true }) {
  const split = splitUrl(url);
  const bodyPart = buildBodyArguments(bodyExpression);
  return `<HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="${xmlEscape(name)}" enabled="true">${bodyPart}<stringProp name="HTTPSampler.domain">${xmlEscape(split.domain)}</stringProp><stringProp name="HTTPSampler.port"></stringProp><stringProp name="HTTPSampler.protocol">${xmlEscape(split.protocol)}</stringProp><stringProp name="HTTPSampler.path">${xmlEscape(split.path)}</stringProp><stringProp name="HTTPSampler.method">${xmlEscape(method)}</stringProp><boolProp name="HTTPSampler.follow_redirects">${followRedirects ? 'true' : 'false'}</boolProp><boolProp name="HTTPSampler.auto_redirects">false</boolProp><boolProp name="HTTPSampler.use_keepalive">true</boolProp><boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp><stringProp name="HTTPSampler.embedded_url_re"></stringProp></HTTPSamplerProxy>`;
}

function buildApiEncryptionScripts(settings) {
  const mode = String(settings.encryptionMode || 'none');
  if (mode === 'none') {
    return '<hashTree/>';
  }

  if (mode === 'base64') {
    return `<JSR223PreProcessor guiclass="TestBeanGUI" testclass="JSR223PreProcessor" testname="Base64 Payload PreProcessor" enabled="true"><stringProp name="cacheKey">true</stringProp><stringProp name="scriptLanguage">groovy</stringProp><stringProp name="script">def raw = vars.get('raw_payload') ?: ''\nvars.put('payload', raw.bytes.encodeBase64().toString())</stringProp></JSR223PreProcessor><hashTree/>`;
  }

  const key = xmlEscape(settings.aesKey || '0123456789abcdef');
  const iv = xmlEscape(settings.aesIv || 'abcdef9876543210');
  return `<JSR223PreProcessor guiclass="TestBeanGUI" testclass="JSR223PreProcessor" testname="AES-CBC Encrypt Payload" enabled="true"><stringProp name="cacheKey">true</stringProp><stringProp name="scriptLanguage">groovy</stringProp><stringProp name="script">import javax.crypto.Cipher\nimport javax.crypto.spec.IvParameterSpec\nimport javax.crypto.spec.SecretKeySpec\ndef raw = vars.get('raw_payload') ?: ''\ndef secret = new SecretKeySpec('${key}'.getBytes('UTF-8'), 'AES')\ndef ivSpec = new IvParameterSpec('${iv}'.getBytes('UTF-8'))\ndef cipher = Cipher.getInstance('AES/CBC/PKCS5Padding')\ncipher.init(Cipher.ENCRYPT_MODE, secret, ivSpec)\ndef encrypted = cipher.doFinal(raw.getBytes('UTF-8')).encodeBase64().toString()\nvars.put('payload', encrypted)</stringProp></JSR223PreProcessor><hashTree/>`;
}

function buildApiPostDecrypt(settings) {
  if (String(settings.encryptionMode || 'none') !== 'aes-cbc') {
    return '<hashTree/>';
  }

  const key = xmlEscape(settings.aesKey || '0123456789abcdef');
  const iv = xmlEscape(settings.aesIv || 'abcdef9876543210');
  return `<JSR223PostProcessor guiclass="TestBeanGUI" testclass="JSR223PostProcessor" testname="AES-CBC Decrypt Response" enabled="true"><stringProp name="scriptLanguage">groovy</stringProp><stringProp name="script">import javax.crypto.Cipher\nimport javax.crypto.spec.IvParameterSpec\nimport javax.crypto.spec.SecretKeySpec\ntry {\n  def enc = prev.getResponseDataAsString()?.trim()\n  if (enc) {\n    def secret = new SecretKeySpec('${key}'.getBytes('UTF-8'), 'AES')\n    def ivSpec = new IvParameterSpec('${iv}'.getBytes('UTF-8'))\n    def cipher = Cipher.getInstance('AES/CBC/PKCS5Padding')\n    cipher.init(Cipher.DECRYPT_MODE, secret, ivSpec)\n    def decoded = cipher.doFinal(enc.decodeBase64())\n    vars.put('decrypted_response', new String(decoded, 'UTF-8'))\n  }\n} catch (Exception ex) {\n  log.warn('Response decrypt failed: ' + ex.getMessage())\n}</stringProp></JSR223PostProcessor><hashTree/>`;
}

function buildPlanSpecificTree(plan) {
  if (plan.type === 'website') {
    const headers = parseJsonObject(plan.settings.headersJson || '{}', 'Website headers');
    const sampler = buildHttpSampler({
      name: 'Website Request',
      method: String(plan.settings.method || 'GET').toUpperCase(),
      url: String(plan.settings.targetUrl),
      bodyExpression: plan.settings.body || '',
      followRedirects: Boolean(plan.settings.followRedirects)
    });

    return `${sampler}<hashTree>${buildHeaderManager(headers)}</hashTree>`;
  }

  if (plan.type === 'api') {
    const method = String(plan.settings.method || 'POST').toUpperCase();
    const baseUrl = String(plan.settings.baseUrl).replace(/\/$/, '');
    const endpoint = String(plan.settings.endpointPath || '').startsWith('/')
      ? String(plan.settings.endpointPath)
      : `/${String(plan.settings.endpointPath || '')}`;

    const headers = parseJsonObject(plan.settings.headersJson || '{}', 'API headers');
    const authType = String(plan.settings.authType || 'none');

    if (authType === 'bearer' && plan.settings.bearerToken) {
      headers.Authorization = `Bearer ${plan.settings.bearerToken}`;
    }
    if (authType === 'apiKey') {
      headers[String(plan.settings.apiKeyName)] = String(plan.settings.apiKeyValue);
    }
    if (authType === 'basic') {
      const raw = `${plan.settings.authUsername}:${plan.settings.authPassword}`;
      headers.Authorization = `Basic ${Buffer.from(raw).toString('base64')}`;
    }

    if (!headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    const body = String(plan.settings.body || '');
    const encryptionMode = String(plan.settings.encryptionMode || 'none');
    const payloadExpr = encryptionMode === 'none' ? body : '${payload}';

    const userVars = `<Arguments guiclass="ArgumentsPanel" testclass="Arguments" testname="API Variables" enabled="true"><collectionProp name="Arguments.arguments"><elementProp name="raw_payload" elementType="Argument"><stringProp name="Argument.name">raw_payload</stringProp><stringProp name="Argument.value">${xmlEscape(body)}</stringProp><stringProp name="Argument.metadata">=</stringProp></elementProp></collectionProp></Arguments><hashTree/>`;

    const sampler = buildHttpSampler({
      name: 'API Request',
      method,
      url: `${baseUrl}${endpoint}`,
      bodyExpression: payloadExpr,
      followRedirects: false
    });

    return `${userVars}${buildApiEncryptionScripts(plan.settings)}${sampler}<hashTree>${buildHeaderManager(headers)}${buildApiPostDecrypt(plan.settings)}</hashTree>`;
  }

  const gatewayBase = String(plan.settings.gatewayBaseUrl).replace(/\/$/, '');
  const initiatePath = String(plan.settings.initiatePath).startsWith('/')
    ? String(plan.settings.initiatePath)
    : `/${String(plan.settings.initiatePath)}`;
  const statusPath = String(plan.settings.statusPath).startsWith('/')
    ? String(plan.settings.statusPath)
    : `/${String(plan.settings.statusPath)}`;
  const tokenHeader = String(plan.settings.gatewayAuthHeader || 'Authorization');
  const tokenValue = String(plan.settings.gatewayAuthValue || 'Bearer demo-token');

  const headers = {
    'Content-Type': 'application/json',
    [tokenHeader]: tokenValue
  };

  const initBody = JSON.stringify({
    amount: Number(plan.settings.amount || 100),
    currency: String(plan.settings.currency || 'INR'),
    orderId: String(plan.settings.orderIdPrefix || 'ORD') + '-${__time(YMDHMS)}'
  });

  const initSampler = buildHttpSampler({
    name: 'Payment Initiate',
    method: 'POST',
    url: `${gatewayBase}${initiatePath}`,
    bodyExpression: initBody,
    followRedirects: false
  });

  const extractTxn = `<JSONPostProcessor guiclass="JSONPostProcessorGui" testclass="JSONPostProcessor" testname="Extract Transaction Id" enabled="true"><stringProp name="JSONPostProcessor.referenceNames">txn_id</stringProp><stringProp name="JSONPostProcessor.jsonPathExprs">$.transactionId</stringProp><stringProp name="JSONPostProcessor.match_numbers">1</stringProp><stringProp name="JSONPostProcessor.defaultValues">NOT_FOUND</stringProp></JSONPostProcessor>`;

  const statusSampler = buildHttpSampler({
    name: 'Payment Status',
    method: 'GET',
    url: `${gatewayBase}${statusPath}?transactionId=${'${txn_id}'}`,
    bodyExpression: '',
    followRedirects: false
  });

  return `${initSampler}<hashTree>${buildHeaderManager(headers)}${extractTxn}<hashTree/></hashTree>${statusSampler}<hashTree>${buildHeaderManager(headers)}</hashTree>`;
}

function buildJmx(plan, username) {
  if (plan.type === 'manual') {
    return String(plan.settings.manualScript || '').trim();
  }

  const thread = `<ThreadGroup guiclass="ThreadGroupGui" testclass="ThreadGroup" testname="Thread Group" enabled="true"><stringProp name="ThreadGroup.on_sample_error">continue</stringProp><elementProp name="ThreadGroup.main_controller" elementType="LoopController" guiclass="LoopControlPanel" testclass="LoopController" testname="Loop Controller" enabled="true"><boolProp name="LoopController.continue_forever">false</boolProp><stringProp name="LoopController.loops">${xmlEscape(plan.load.loops)}</stringProp></elementProp><stringProp name="ThreadGroup.num_threads">${xmlEscape(plan.load.users)}</stringProp><stringProp name="ThreadGroup.ramp_time">${xmlEscape(plan.load.rampUp)}</stringProp><boolProp name="ThreadGroup.scheduler">false</boolProp><stringProp name="ThreadGroup.duration"></stringProp><stringProp name="ThreadGroup.delay"></stringProp></ThreadGroup>`;

  const testPlan = `<TestPlan guiclass="TestPlanGui" testclass="TestPlan" testname="${xmlEscape(plan.name)}" enabled="true"><stringProp name="TestPlan.comments">Generated by JMeter Control Panel for ${xmlEscape(username)}</stringProp><boolProp name="TestPlan.functional_mode">false</boolProp><boolProp name="TestPlan.tearDown_on_shutdown">true</boolProp><boolProp name="TestPlan.serialize_threadgroups">false</boolProp><elementProp name="TestPlan.user_defined_variables" elementType="Arguments" guiclass="ArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true"><collectionProp name="Arguments.arguments"/></elementProp><stringProp name="TestPlan.user_define_classpath"></stringProp></TestPlan>`;

  return `<?xml version="1.0" encoding="UTF-8"?>
<jmeterTestPlan version="1.2" properties="5.0" jmeter="5.6.3">
  <hashTree>
    ${testPlan}
    <hashTree>
      ${thread}
      <hashTree>
        ${buildPlanSpecificTree(plan)}
      </hashTree>
    </hashTree>
  </hashTree>
</jmeterTestPlan>
`;
}

function appendLog(line) {
  runState.logs.push(`${new Date().toISOString()} ${line}`);
  if (runState.logs.length > 800) {
    runState.logs = runState.logs.slice(-800);
  }
}

function getElapsedSeconds() {
  if (!runState.running || !runState.startedAt) return 0;
  return Math.floor((Date.now() - new Date(runState.startedAt).getTime()) / 1000);
}

function getQueueSnapshot() {
  return runQueue.map((job, index) => ({
    id: job.id,
    username: job.username,
    requestedAt: job.requestedAt,
    position: index + 1
  }));
}

function ensureJMeterWritable() {
  if (!JMETER_PATH) {
    throw new Error('JMETER_PATH is not configured. Set it in .env.');
  }
  if (!fs.existsSync(JMETER_PATH)) {
    throw new Error(`JMETER_PATH does not exist: ${JMETER_PATH}`);
  }
  if (!fs.existsSync(JMETER_BIN)) {
    throw new Error(`jmeter binary not found at: ${JMETER_BIN}`);
  }
}

function executeRunJob(job) {
  ensureJMeterWritable();

  if (fs.existsSync(TEST_FILE)) {
    fs.unlinkSync(TEST_FILE);
    appendLog(`Removed previous test plan: ${TEST_FILE_NAME}`);
  }

  const jmx = buildJmx(job.plan, job.username);
  fs.writeFileSync(TEST_FILE, jmx, 'utf-8');
  appendLog(`Saved new test plan: ${TEST_FILE_NAME}`);

  const reportFolder = `${REPORT_PREFIX}${Date.now()}`;
  const reportPath = path.join(JMETER_PATH, reportFolder);

  if (fs.existsSync(RESULTS_FILE)) {
    fs.unlinkSync(RESULTS_FILE);
  }
  if (fs.existsSync(reportPath)) {
    fs.rmSync(reportPath, { recursive: true, force: true });
  }

  runState.running = true;
  runState.currentJobId = job.id;
  runState.currentJobStartedAt = new Date().toISOString();
  runState.startedAt = new Date().toISOString();
  runState.startedBy = job.username;
  runState.reportFolder = reportFolder;
  runState.logs = [];

  runState.lastRun = {
    startedAt: runState.startedAt,
    finishedAt: null,
    startedBy: job.username,
    reportFolder,
    exitCode: null,
    status: 'running'
  };

  metrics.runStarted += 1;

  const args = ['-n', '-t', TEST_FILE_NAME, '-l', RESULTS_FILE_NAME, '-e', '-o', reportFolder];
  appendLog(`Run started by ${job.username} (job ${job.id})`);
  appendLog(`Command: ./jmeter ${args.join(' ')}`);

  const child = spawn('./jmeter', args, { cwd: JMETER_PATH });
  currentRunChild = child;

  if (currentRunTimer) {
    clearTimeout(currentRunTimer);
    currentRunTimer = null;
  }

  currentRunTimer = setTimeout(() => {
    if (runState.running && currentRunChild && !currentRunChild.killed) {
      appendLog(`Run timeout reached (${RUN_TIMEOUT_SECONDS}s). Killing stuck JMeter process.`);
      try {
        currentRunChild.kill('SIGTERM');
      } catch (err) {
        appendLog(`Failed to terminate timed-out process gracefully: ${err.message}`);
      }

      setTimeout(() => {
        if (runState.running && currentRunChild && !currentRunChild.killed) {
          try {
            currentRunChild.kill('SIGKILL');
            appendLog('Forced SIGKILL on stuck JMeter process.');
          } catch (err) {
            appendLog(`Failed SIGKILL for stuck process: ${err.message}`);
          }
        }
      }, 5000);
    }
  }, Math.max(30, RUN_TIMEOUT_SECONDS) * 1000);

  child.stdout.on('data', (data) => {
    const lines = data.toString().split(/\r?\n/).filter(Boolean);
    lines.forEach((line) => appendLog(line));
    process.stdout.write(data.toString());
  });

  child.stderr.on('data', (data) => {
    const lines = data.toString().split(/\r?\n/).filter(Boolean);
    lines.forEach((line) => appendLog(`ERROR ${line}`));
    process.stderr.write(data.toString());
  });

  child.on('close', (code) => {
    if (currentRunTimer) {
      clearTimeout(currentRunTimer);
      currentRunTimer = null;
    }
    runState.running = false;
    runState.currentJobId = null;
    runState.currentJobStartedAt = null;
    runState.latestReport = reportFolder;
    runState.lastRun.finishedAt = new Date().toISOString();
    runState.lastRun.exitCode = code;
    runState.lastRun.status = code === 0 ? 'completed' : 'failed';
    if (code === 0) {
      metrics.runCompleted += 1;
    } else {
      metrics.runFailed += 1;
    }
    appendLog(code === 0 ? 'Run completed.' : `Run failed with exit code ${code}.`);
    currentRunChild = null;
    processRunQueue();
  });

  child.on('error', (err) => {
    if (currentRunTimer) {
      clearTimeout(currentRunTimer);
      currentRunTimer = null;
    }
    runState.running = false;
    runState.currentJobId = null;
    runState.currentJobStartedAt = null;
    runState.lastRun.finishedAt = new Date().toISOString();
    runState.lastRun.exitCode = -1;
    runState.lastRun.status = 'failed';
    metrics.runFailed += 1;
    appendLog(`Run start failure: ${err.message}`);
    currentRunChild = null;
    processRunQueue();
  });

  return { reportFolder };
}

function processRunQueue() {
  if (runState.running) {
    return;
  }

  const nextJob = runQueue.shift();
  if (!nextJob) {
    return;
  }

  try {
    executeRunJob(nextJob);
  } catch (err) {
    runState.running = false;
    runState.currentJobId = null;
    runState.lastRun.finishedAt = new Date().toISOString();
    runState.lastRun.exitCode = -1;
    runState.lastRun.status = 'failed';
    metrics.runFailed += 1;
    appendLog(`Queue job ${nextJob.id} failed before execution: ${err.message}`);
    processRunQueue();
  }
}

ensureDirs();
ensureAdminUser();
selfHealArtifacts();
runPreflightChecks();

app.disable('x-powered-by');
app.set('trust proxy', 1);

app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: '2mb' }));
app.use(applySecurityHeaders);
app.use('/api', apiLimiter);
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: false
    }
  })
);

function requireAuth(req, res, next) {
  if (!req.session.user) {
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
    return res.redirect('/login.html');
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin access required.' });
  }
  next();
}

app.get('/', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login.html');
  }
  return res.redirect('/app');
});

app.get('/app', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'app.html'));
});

app.post('/login', loginLimiter, (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');

  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password are required.' });
  }

  const users = readUsers();
  const user = users.find((u) => u.username === username);
  if (!user) {
    metrics.authFailures += 1;
    return res.status(401).json({ success: false, message: 'Invalid credentials.' });
  }

  if (!verifyPassword(password, user.salt, user.passwordHash)) {
    metrics.authFailures += 1;
    return res.status(401).json({ success: false, message: 'Invalid credentials.' });
  }

  metrics.authSuccess += 1;
  req.session.user = getSafeUser(user);
  return res.json({ success: true, user: req.session.user });
});

app.post('/logout', requireAuth, (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true });
  });
});

app.get('/api/me', requireAuth, (req, res) => {
  return res.json({
    success: true,
    user: req.session.user,
    running: runState.running,
    startedBy: runState.startedBy,
    elapsedSeconds: getElapsedSeconds()
  });
});

app.get('/api/plan-types', requireAuth, (req, res) => {
  res.json({ success: true, planTypes: PLAN_TYPES });
});

app.get('/api/plan/my', requireAuth, (req, res) => {
  const plan = readUserPlan(req.session.user.username);
  return res.json({ success: true, plan });
});

app.post('/api/plan/my', requireAuth, (req, res) => {
  try {
    const saved = saveUserPlan(req.session.user.username, req.body.plan);
    return res.json({ success: true, plan: saved, message: 'Plan saved for current user.' });
  } catch (err) {
    return res.status(400).json({ success: false, message: err.message });
  }
});

app.post('/api/run', requireAuth, runLimiter, (req, res) => {
  if (runQueue.length >= MAX_QUEUE_SIZE) {
    return res.status(429).json({
      success: false,
      message: `Run queue is full (max ${MAX_QUEUE_SIZE}). Please retry later.`
    });
  }

  const plan = readUserPlan(req.session.user.username);

  try {
    const queuedAhead = runQueue.length + (runState.running ? 1 : 0);
    const job = {
      id: nextRunJobId++,
      username: req.session.user.username,
      plan,
      requestedAt: new Date().toISOString()
    };

    runQueue.push(job);
    metrics.runEnqueued += 1;
    appendLog(`Run job ${job.id} queued by ${job.username}. Ahead in queue: ${queuedAhead}`);

    if (!runState.running) {
      processRunQueue();
    }

    const startedNow = runState.currentJobId === job.id;

    return res.json({
      success: true,
      message: startedNow
        ? 'Test run started successfully.'
        : `Run is queued. Position in queue: ${queuedAhead}.`,
      started: startedNow,
      queuePosition: startedNow ? 0 : queuedAhead,
      queueLength: runQueue.length,
      jobId: job.id
    });
  } catch (err) {
    return res.status(400).json({ success: false, message: err.message });
  }
});

app.get('/api/queue', requireAuth, (req, res) => {
  return res.json({
    success: true,
    running: runState.running,
    currentJobId: runState.currentJobId,
    startedBy: runState.startedBy,
    elapsedSeconds: getElapsedSeconds(),
    queueLength: runQueue.length,
    queue: getQueueSnapshot()
  });
});

app.delete('/api/queue/:jobId', requireAuth, (req, res) => {
  const jobId = Number(req.params.jobId);
  if (!Number.isInteger(jobId) || jobId <= 0) {
    return res.status(400).json({ success: false, message: 'Invalid queue job id.' });
  }

  const idx = runQueue.findIndex((j) => j.id === jobId);
  if (idx === -1) {
    return res.status(404).json({ success: false, message: 'Queue job not found.' });
  }

  const job = runQueue[idx];
  const isAdmin = req.session.user.role === 'admin';
  if (!isAdmin && job.username !== req.session.user.username) {
    return res.status(403).json({ success: false, message: 'You can cancel only your own queued jobs.' });
  }

  runQueue.splice(idx, 1);
  appendLog(`Queue job ${job.id} cancelled by ${req.session.user.username}.`);
  return res.json({ success: true, message: `Queue job ${job.id} cancelled.` });
});

app.post('/api/queue/clear', requireAuth, requireAdmin, (req, res) => {
  const cleared = runQueue.length;
  runQueue.splice(0, runQueue.length);
  appendLog(`Queue cleared by admin ${req.session.user.username}. Removed ${cleared} jobs.`);
  return res.json({ success: true, message: `Cleared ${cleared} queued jobs.` });
});

app.get('/api/preflight', requireAuth, (req, res) => {
  const snapshot = runPreflightChecks();
  return res.json({ success: true, preflight: snapshot });
});

app.get('/api/status', requireAuth, (req, res) => {
  const preflight = runPreflightChecks();
  const canDeleteReports = req.session.user.role === 'admin';
  res.json({
    success: true,
    serverStartedAt: new Date(serverStartedAt).toISOString(),
    uptimeSeconds: Math.floor((Date.now() - serverStartedAt) / 1000),
    running: runState.running,
    currentJobId: runState.currentJobId,
    currentJobStartedAt: runState.currentJobStartedAt,
    startedBy: runState.startedBy,
    runTimeoutSeconds: RUN_TIMEOUT_SECONDS,
    elapsedSeconds: getElapsedSeconds(),
    queueLength: runQueue.length,
    queuedByUsers: getQueueSnapshot().map((q) => q.username),
    latestReport: runState.latestReport,
    reportServerPort: REPORT_SERVER_PORT,
    canDeleteReports,
    jmeterPath: JMETER_PATH_DISPLAY,
    jmeterBinaryExists: fs.existsSync(JMETER_BIN),
    testFile: TEST_FILE,
    resultFile: RESULTS_FILE,
    lastRun: runState.lastRun,
    preflight
  });
});

app.get('/api/logs', requireAuth, (req, res) => {
  res.json({
    success: true,
    running: runState.running,
    queueLength: runQueue.length,
    elapsedSeconds: getElapsedSeconds(),
    logs: runState.logs.slice(-300)
  });
});

app.get('/api/reports', requireAuth, (req, res) => {
  if (!JMETER_PATH) {
    return res.json({
      success: true,
      reports: [],
      canDeleteReports: req.session.user.role === 'admin',
      warning: 'JMETER_PATH is not configured.'
    });
  }

  if (!fs.existsSync(JMETER_PATH)) {
    return res.json({
      success: true,
      reports: [],
      canDeleteReports: req.session.user.role === 'admin',
      warning: `JMETER_PATH does not exist: ${JMETER_PATH}`
    });
  }

  let reports = [];
  try {
    const files = fs.readdirSync(JMETER_PATH, { withFileTypes: true });
    reports = files
      .filter((f) => f.isDirectory() && f.name.startsWith(REPORT_PREFIX))
      .map((f) => ({
        name: f.name,
        timestamp: Number(String(f.name).replace(REPORT_PREFIX, '')),
        isLatest: f.name === runState.latestReport
      }))
      .sort((a, b) => b.timestamp - a.timestamp);
  } catch (err) {
    return res.status(400).json({ success: false, message: `Unable to read reports: ${err.message}` });
  }

  return res.json({
    success: true,
    reports,
    canDeleteReports: req.session.user.role === 'admin'
  });
});

app.delete('/api/reports/:name', requireAuth, requireAdmin, (req, res) => {
  const folder = String(req.params.name || '');
  if (!new RegExp(`^${REPORT_PREFIX}\\d+$`).test(folder)) {
    return res.status(400).json({ success: false, message: 'Invalid report folder.' });
  }

  const target = path.join(JMETER_PATH, folder);
  try {
    fs.rmSync(target, { recursive: true, force: true });
    if (runState.latestReport === folder) {
      runState.latestReport = null;
    }
    metrics.reportsDeleted += 1;
    return res.json({ success: true, message: 'Report deleted.' });
  } catch (err) {
    return res.status(500).json({ success: false, message: `Delete failed: ${err.message}` });
  }
});

app.get('/healthz', (req, res) => {
  return res.json({
    status: 'ok',
    service: 'jmeter',
    uptimeSeconds: Math.floor((Date.now() - serverStartedAt) / 1000),
    running: runState.running,
    queueLength: runQueue.length
  });
});

app.get('/readyz', (req, res) => {
  const preflight = runPreflightChecks();
  const checks = {
    jmeterPathExists: fs.existsSync(JMETER_PATH),
    jmeterBinaryExists: fs.existsSync(JMETER_BIN),
    dataDirExists: fs.existsSync(DATA_DIR),
    usersFileExists: fs.existsSync(USERS_FILE),
    preflightHealthy: preflight.healthy
  };

  const ready = Object.values(checks).every(Boolean);
  if (!ready) {
    return res.status(503).json({ status: 'not-ready', checks, suggestedFixes: preflight.suggestedFixes });
  }

  return res.json({ status: 'ready', checks });
});

app.get('/metrics', (req, res) => {
  return res.json({
    service: 'jmeter',
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor((Date.now() - serverStartedAt) / 1000),
    queue: {
      maxSize: MAX_QUEUE_SIZE,
      length: runQueue.length,
      running: runState.running,
      currentJobId: runState.currentJobId,
      timeoutSeconds: RUN_TIMEOUT_SECONDS
    },
    runs: {
      enqueued: metrics.runEnqueued,
      started: metrics.runStarted,
      completed: metrics.runCompleted,
      failed: metrics.runFailed,
      latestReport: runState.latestReport
    },
    auth: {
      success: metrics.authSuccess,
      failures: metrics.authFailures
    },
    reports: {
      deleted: metrics.reportsDeleted
    },
    preflight: preflightState
  });
});

app.get('/api/report/latest', requireAuth, (req, res) => {
  if (!runState.latestReport) {
    return res.status(404).json({ success: false, message: 'No report available yet.' });
  }
  return res.json({
    success: true,
    url: `/report/${runState.latestReport}/index.html`
  });
});

app.get('/api/users', requireAuth, requireAdmin, (req, res) => {
  const users = readUsers().map(getSafeUser);
  return res.json({ success: true, users });
});

app.post('/api/users', requireAuth, requireAdmin, (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  const confirmPassword = String(req.body.confirmPassword || '');
  const email = String(req.body.email || '').trim().toLowerCase();

  if (!username || !password || !confirmPassword || !email) {
    return res.status(400).json({ success: false, message: 'username, password, confirmPassword, and email are required.' });
  }
  if (password !== confirmPassword) {
    return res.status(400).json({ success: false, message: 'Password and confirm password must match.' });
  }
  if (username === ADMIN_USER.username) {
    return res.status(400).json({ success: false, message: 'admin username is reserved.' });
  }

  const users = readUsers();
  if (users.some((u) => u.username === username)) {
    return res.status(400).json({ success: false, message: 'Username already exists.' });
  }
  if (users.some((u) => u.email === email)) {
    return res.status(400).json({ success: false, message: 'Email already exists.' });
  }

  const secure = makePasswordHash(password);
  const user = {
    username,
    email,
    role: 'user',
    passwordHash: secure.hash,
    salt: secure.salt,
    createdAt: new Date().toISOString()
  };

  users.push(user);
  writeUsers(users);
  return res.json({ success: true, user: getSafeUser(user), message: 'User created successfully.' });
});

app.delete('/api/users/:username', requireAuth, requireAdmin, (req, res) => {
  const targetUsername = String(req.params.username || '').trim();
  if (!targetUsername) {
    return res.status(400).json({ success: false, message: 'Username is required.' });
  }
  if (targetUsername === ADMIN_USER.username) {
    return res.status(400).json({ success: false, message: 'Admin user cannot be deleted.' });
  }

  const users = readUsers();
  const idx = users.findIndex((u) => u.username === targetUsername);
  if (idx === -1) {
    return res.status(404).json({ success: false, message: 'User not found.' });
  }

  users.splice(idx, 1);
  writeUsers(users);

  const planFile = getPlanFile(targetUsername);
  if (fs.existsSync(planFile)) {
    fs.rmSync(planFile, { force: true });
  }

  return res.json({ success: true, message: 'User deleted.' });
});

if (JMETER_PATH) {
  app.use('/report', requireAuth, express.static(JMETER_PATH));
} else {
  app.use('/report', requireAuth, (req, res) => {
    return res.status(400).json({ success: false, message: 'JMETER_PATH is not configured.' });
  });
}

app.listen(PORT, () => {
  console.log(`JMeter Control Panel running at http://localhost:${PORT}`);
  console.log(`JMeter path: ${JMETER_PATH_DISPLAY}`);
  console.log(`Report server port (external): ${REPORT_SERVER_PORT}`);
});
