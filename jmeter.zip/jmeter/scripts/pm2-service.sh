#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${BASE_DIR}/app"
APP_NAME="jmeter"
CONFIG_FILE="${BASE_DIR}/config/config.env"

if [[ -f "${CONFIG_FILE}" ]]; then
  # shellcheck disable=SC1090
  source "${CONFIG_FILE}"
  APP_NAME="${PM2_APP_NAME:-jmeter}"
fi

ACTION="${1:-start}"

case "$ACTION" in
  start)
    bash "${BASE_DIR}/start.sh"
    ;;
  stop)
    bash "${BASE_DIR}/stop.sh"
    ;;
  restart)
    bash "${BASE_DIR}/restart.sh"
    ;;
  delete)
    pm2 delete "$APP_NAME"
    ;;
  status)
    pm2 status "$APP_NAME"
    ;;
  logs)
    pm2 logs "$APP_NAME"
    ;;
  startup)
    pm2 startup
    ;;
  save)
    pm2 save
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|delete|status|logs|startup|save}"
    exit 1
    ;;
esac
