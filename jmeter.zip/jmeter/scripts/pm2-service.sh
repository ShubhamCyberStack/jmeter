#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_NAME="jmeter"

ACTION="${1:-start}"

case "$ACTION" in
  start)
    cd "$APP_DIR"
    pm2 start ecosystem.config.cjs --only "$APP_NAME"
    pm2 save
    ;;
  stop)
    pm2 stop "$APP_NAME"
    ;;
  restart)
    pm2 restart "$APP_NAME"
    ;;
  delete)
    pm2 delete "$APP_NAME"
    ;;
  status)
    pm2 status "$APP_NAME"
    ;;
  logs)
    pm2 logs "$APP_NAME"
    ;;
  startup)
    pm2 startup
    ;;
  save)
    pm2 save
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|delete|status|logs|startup|save}"
    exit 1
    ;;
esac
